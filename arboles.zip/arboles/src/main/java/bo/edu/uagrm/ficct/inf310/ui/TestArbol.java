

package bo.edu.uagrm.ficct.inf310.ui;

import bo.edu.uagrm.ficct.inf310.arboles.*;

import java.io.InputStream;
import java.util.Scanner;

public class TestArbol {
    public static  void main(String[] args) throws ExceptionClaveYaExiste, ExceptionClaveNoExiste {
        IArbolBusqueda<Integer, String> arbolDeBusqueda;
        Scanner entrada = new Scanner(System.in);
        System.out.println("Elija un tipo de árbol(ABB, AVL, AMV)");
        String tipoArbol = entrada.next();
        tipoArbol = tipoArbol.toUpperCase();

        switch (tipoArbol) {
            case "ABB" :
                arbolDeBusqueda = new ArbolBinarioBusqueda<Integer, String>();
                break;
            case "AVL" :
                arbolDeBusqueda = new AVL<Integer, String>();
                break;
            case "AMV" :
                arbolDeBusqueda = new ArbolMviasBusqueda<Integer, String>();
                break;
            default:
                System.out.println("Tipo de árbol invalido, eligiendo ArbolBinarioBusqueda\n");
                arbolDeBusqueda = new ArbolBinarioBusqueda<Integer, String>();
        }

        arbolDeBusqueda.insertar(5 ,"Julio Gonzales");
        arbolDeBusqueda.insertar(65,"Liz Llanos");
        arbolDeBusqueda.insertar(19,"Dilker Cartagena");
        arbolDeBusqueda.insertar(82,"Gabriel Coca");
        arbolDeBusqueda.insertar(18,"Luis Fernando");
        arbolDeBusqueda.insertar(72,"Alejandro Cruz");
        arbolDeBusqueda.insertar(32,"Carlos Angola");
        arbolDeBusqueda.insertar(2,"Alberto Angola");

        System.out.println(arbolDeBusqueda.toString());

  /*      System.out.println("----------------------------------------------------------------------");
  Métodos de ÁrbolBinarioBúsqueda
        System.out.println("Valor buscado = " + arbolDeBusqueda.buscar(0));
        System.out.println("Nivel del árbol binario = " + arbolDeBusqueda.nivel());

        System.out.println("Recorrido por Niveles = " + arbolDeBusqueda.recorridoPorNiveles());
        System.out.println("Recorrido en Preorden = " + arbolDeBusqueda.recorridoEnPreorden());
        System.out.println("Recorrido en InOrden = " + arbolDeBusqueda.recorridoEnInorden());
        System.out.println("Cantidad de nodos en el arbol = " + arbolDeBusqueda.size());
*/
        if(arbolDeBusqueda instanceof ArbolBinarioBusqueda) {
            System.out.println("Recorrido en InOrden Recursivo = "   + (((ArbolBinarioBusqueda<Integer, String>)arbolDeBusqueda).recorridoInOrdenRecursivo()));
            System.out.println("Recorrido en PostOrden Iterativo = " + ((ArbolBinarioBusqueda<Integer, String>) arbolDeBusqueda).recorridoPostOrdenIterativo());
        }/*
        System.out.println("Recorrido en PostOrden Recursivo = " + arbolDeBusqueda.recorridoEnPostorden());
        System.out.println("Recorrido en PreOrden Recursivo = " + ((ArbolBinarioBusqueda)arbolDeBusqueda).recorridoEnPreordenRecursivo());
        System.out.println("Altura del arbol = " + arbolDeBusqueda.altura());
        //System.out.println("Valor eliminado = " + arbolDeBusqueda.eliminar(65)); anulamos esto para poder realizar los Ejercicios ABB
        //System.out.println(arbolDeBusqueda);
        System.out.println("Recorrido por Niveles = " + arbolDeBusqueda.recorridoPorNiveles());
        System.out.println("Cantidad de nodos incompletos desde nivel = " + ((ArbolBinarioBusqueda<Integer, String>) arbolDeBusqueda).cantidadDeNodosIncompletosDesdeNivel(2));
*/

        System.out.println("Trabajo practico Arbol Binario");
        System.out.println("(1) Cantidad de nodos hojas recursivo: " + ((ArbolBinarioBusqueda<Integer, String>) arbolDeBusqueda).cantidadDeNodosHojaRecursivo());

        System.out.println("(2) Cantidad de nodos hojas iterativo: " + ((ArbolBinarioBusqueda<Integer, String>) arbolDeBusqueda).cantidadDeNodosHojaIteretivo());

        InputStream stream1 = System.in;
        System.out.println("(3) Implemente un método recursivo que retorne la cantidad nodos hojas que existen en un árbol binario, pero solo en el nivel N ");
        Scanner teclado1 = new Scanner(stream1);
        System.out.print("Introducir el nivel: ");
        String input1 = teclado1.next();
        int i1 = Integer.parseInt(input1);
        //scanner.close();
        System.out.println("Respuesta:" + ((ArbolBinarioBusqueda<Integer, String>)arbolDeBusqueda).cantDeNodosHDesdeNivelRecursivo(i1));

        InputStream stream2 = System.in;
        System.out.println("(4) Implemente un método iterativo que retorne la cantidad nodos hojas que existen en un árbol binario, pero solo en el nivel N");
        Scanner teclado2 = new Scanner(stream2);
        System.out.print("Introducir el nivel: ");
        String input2 = teclado2.next();
        int i2 = Integer.parseInt(input2);
        System.out.println("Respuesta:" + ((ArbolBinarioBusqueda<Integer, String>)arbolDeBusqueda).cantDeNodosHDesdeNivelIterativo(i2));

        InputStream stream3 = System.in;
        System.out.println("(5) Implemente un método iterativo que retorne la cantidad nodos hojas que existen en un árbol binario, pero solo antes del nivel N");
        Scanner teclado3 = new Scanner(stream3);
        System.out.print("Introducir el nivel: ");
        String input3 = teclado3.next();
        int i3 = Integer.parseInt(input3);
        System.out.println("Respuesta:" + ((ArbolBinarioBusqueda<Integer, String>)arbolDeBusqueda).cantDeNodosHAntesDeNivelIterativo(i3));

        System.out.println("(6) Implemente un método recursivo que retorne verdadero, si un árbol binario esta balanceado según las reglas que establece un árbol AVL, falso en caso contrario");
        System.out.println("Respuesta para el arbol actual:" + ((ArbolBinarioBusqueda<Integer, String>)arbolDeBusqueda).esArbolBalancedo());

        System.out.println("(7) Implemente un método iterativo que la lógica de un recorrido en postorden que retorne verdadero, si un árbol binario esta balanceado según las reglas que establece un árbol AVL, falso en caso contrario");
        System.out.println("Respuesta para el arbol actual: " + ((ArbolBinarioBusqueda<Integer, String>)arbolDeBusqueda).esArbolBalanceadoIterativo());

        //System.out.println("(8)  = " + ((ArbolBinarioBusqueda<Integer, String>)arbolDeBusqueda).;

        InputStream stream4 = System.in;
        System.out.println("(9) Implemente un método privado que reciba un nodo binario de un árbol binario y que retorne cual sería su sucesor inorden de la clave de dicho nodo");
        Scanner teclado4 = new Scanner(stream4);
        System.out.print("Introducir la clave: ");
        String input4 = teclado4.next();
        int i4 = Integer.parseInt(input4);
        System.out.println("Respuesta: Sucesor InOrden " + ((ArbolBinarioBusqueda<Integer, String>)arbolDeBusqueda).claveSucesor(i4));

        InputStream stream5 = System.in;
        System.out.println("(10) Implemente un método privado que reciba un nodo binario de un árbol binario y que retorne cual sería su sucesor inorden de la clave de dicho nodo");
        Scanner teclado5 = new Scanner(stream5);
        System.out.print("Introducir la clave: ");
        String input5 = teclado5.next();
        int i5 = Integer.parseInt(input5);
        System.out.println("Respuesta: Predecesor InOrden " + ((ArbolBinarioBusqueda<Integer, String>)arbolDeBusqueda).clavePredecesor(i5));

        IArbolBusqueda<Integer, String> arbolDePruebaAVL = new AVL<Integer, String>();
        Integer [] arregloIAVL = {54,5,65,19,82,60,1,32,18,72} ;
        String  [] arregloSAVL = {"Cristhian Sosa", "Julio Gonzales", "Liz Llanos", "Dilker Cartagena", "Gabriel Coca",
                "Luis Fernando", "Alejandro Cruz", "Carlos Angola", "Abel López"      , "Alejandro Cabero"};
        int dimensionAVL = arregloIAVL.length;
        for (int i = 0;i < dimensionAVL;i++) {
            arbolDePruebaAVL.insertar(arregloIAVL[i], arregloSAVL[i]);
        }
        arbolDePruebaAVL.toString();
        System.out.println(arbolDePruebaAVL);

        System.out.println("(11) Método eliminar de un arbol AVL");
        System.out.println("Valor asociado a la clave eliminada: " + ((AVL<Integer, String>)arbolDePruebaAVL).eliminar(1));
        System.out.println(arbolDePruebaAVL);

        InputStream stream6 = System.in;
        System.out.println("(12) Para un árbol binario implemente un método que retorne la cantidad de nodos que tienen ambos hijos luego del nivel N");
        Scanner teclado6 = new Scanner(stream6);
        System.out.print("Introducir el nivel: ");
        String input6 = teclado6.next();
        int i6 = Integer.parseInt(input6);
        System.out.println("Respuesta: " + ((ArbolBinarioBusqueda<Integer, String>)arbolDeBusqueda).cantDeNodosConAmbosHijosLuegoDelNivel(i6));

    }
}