package bo.edu.uagrm.ficct.inf310.Examen1;

import bo.edu.uagrm.ficct.inf310.arboles.*;
import java.util.*;

public class ArbolAMV<K extends Comparable<K>, V> extends ArbolMviasBusqueda<K, V> {
    public ArbolAMV(int orden) throws ExcepcionOrdenInvalido {
        super(orden);
    }

    int cantidadDeNodosPadresFueraDelNivel(int nivel){
        int cantidad = 0;
        if (this.esArbolVacio()){
            return cantidad;
        }
        int nivelActual = 0;
        int cantidadDeNodosDelNivelActual;
        Queue<NodoMVias> colaDeNodos = new LinkedList<>();
        colaDeNodos.add(this.raiz);
        while (!colaDeNodos.isEmpty()) {
            cantidadDeNodosDelNivelActual = colaDeNodos.size();
            while(cantidadDeNodosDelNivelActual > 0) {
                NodoMVias<K, V> nodoActual = colaDeNodos.poll();
                if (nivelActual != nivel) {
                    if (!nodoActual.esHoja()) {
                        cantidad = cantidad + 1;
                    }
                }
                for (int i = 0; i < nodoActual.cantidadDeDatosNoVacios(); i++) {
                    if (!nodoActual.esHijoVacio(i)) {
                        colaDeNodos.add(nodoActual.getHijo(i));
                    }
                }
                if (!nodoActual.esHijoVacio(orden - 1)) {
                    colaDeNodos.offer(nodoActual.getHijo(orden - 1));
                }

                cantidadDeNodosDelNivelActual = cantidadDeNodosDelNivelActual - 1;
            }
            nivelActual = nivelActual + 1;
        }
        return cantidad;
    }
}
