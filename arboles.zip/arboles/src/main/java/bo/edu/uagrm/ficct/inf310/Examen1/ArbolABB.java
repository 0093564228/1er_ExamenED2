package bo.edu.uagrm.ficct.inf310.Examen1;

import bo.edu.uagrm.ficct.inf310.arboles.*;

import java.util.*;

public class ArbolABB<K extends Comparable<K>, V> extends ArbolBinarioBusqueda<K, V> {
    public boolean esMonticulo() {
        if (esArbolVacio()){
            return false;
        }
        Queue<NodoBinario<K, V>> colaDeNodos = new LinkedList<>();
        NodoBinario<K, V> nodoActual = this.raiz;
        colaDeNodos.add(nodoActual);

        while(!colaDeNodos.isEmpty()) {
            NodoBinario<K, V> nodoAnterior = nodoActual;
            nodoActual = colaDeNodos.poll();
            if (nodoActual.getClave().compareTo(nodoAnterior.getClave()) < 0) {
                return false;
            }

            if (!nodoActual.esVacioHijoIzquierdo()) {
                colaDeNodos.add(nodoActual.getHijoIzquierdo());
            }
            if (!nodoActual.esVacioHijoDerecho()) {
                colaDeNodos.add(nodoActual.getHijoDerecho());
            }
        }
        return true;
    }
}
