package bo.edu.uagrm.ficct.inf310.ui;

import bo.edu.uagrm.ficct.inf310.arboles.*;
import bo.edu.uagrm.ficct.inf310.arboles.ArbolMviasBusqueda;

public class TestArbolMVias {
    public static void main(String[] args) throws ExceptionClaveYaExiste, ExcepcionOrdenInvalido {
        IArbolBusqueda<Integer, String> arbolDePrueba1 = new ArbolMviasBusqueda<Integer, String>(4);
        Integer [] arregloI = {80,120,200,50,70,75,98,110,130,140,150,400,500,560,72,134,160,170,190,158};
        String  [] arregloS = {"Cristhian Sosa", "Julio Gonzales", "Liz Llanos", "Dilker Cartagena", "Gabriel Coca",
                "Luis Fernando", "Alejandro Cruz", "Carlos Angola", "Abel López", "Alejandro Cabero","1","2","3","4","5","6","7","8","9","10"};
        int dimension = arregloI.length;
        for (int i = 0;i < dimension;i++) {
            arbolDePrueba1.insertar(arregloI[i], arregloS[i]);
        }


        System.out.println("Recorrido por niveles  : " + arbolDePrueba1.recorridoPorNiveles());
        System.out.println("Recorrido por preorden : " + arbolDePrueba1.recorridoEnPreorden());
        System.out.println("Recorrido por inorden  : " + arbolDePrueba1.recorridoEnInorden());
        System.out.println("Recorrido por postorden: " + arbolDePrueba1.recorridoEnPostorden());
        System.out.println("Hojas a partir de nivel: " + ((ArbolMviasBusqueda<Integer, String>)arbolDePrueba1).hojasAPartirDeNivel(0));
        System.out.println("Cantidad de nodos con datos vacios: " + (((ArbolMviasBusqueda<Integer,String>)arbolDePrueba1).cantidadDeNodosConDatosVacios(3)));
    }

}
