package bo.edu.uagrm.ficct.inf310.ui;

import bo.edu.uagrm.ficct.inf310.arboles.*;

import java.util.*;
import java.util.LinkedList;
import java.util.Queue;

public class Prueba<K extends Comparable<K> , V> extends ArbolBinarioBusqueda<K, V> {
    public static void main(String[] args) {
        Prueba<Integer, String> pruebaEXA = new Prueba<Integer, String>();
        try {
            pruebaEXA.insertar(10, "abel0");
            pruebaEXA.insertar(5, "abel1");
            pruebaEXA.insertar(15, "abel2");
            pruebaEXA.insertar(6, "abel3");
            pruebaEXA.insertar(18, "abel5");
            pruebaEXA.insertar(16, "abel9");
            pruebaEXA.insertar(12, "abel7");
            pruebaEXA.insertar(17, "abel8");
            pruebaEXA.insertar(20, "abel9");
            pruebaEXA.insertar(14, "abel10");

            System.out.println(pruebaEXA.toString());
            System.out.println("Cantidad de hijos vacios: " + pruebaEXA.cantidadHijosVacios());
            System.out.println(pruebaEXA.recorridoPostOrden());
            System.out.println("Cantidad de nodos incompletos: " + pruebaEXA.cantidadDeNodosIncompletosDesdeNivel(3));
        }catch (Exception ex) {
            System.out.println("Errores");
        }
    }

    public int cantidadHijosVacios() {
        int cantidadDeHijosVacios = 0;
        if (this.esArbolVacio()){
            return cantidadDeHijosVacios;
        }
        Queue<NodoBinario<K, V>> colaDeNodos = new LinkedList<NodoBinario<K ,V>>();
        NodoBinario<K, V> nodoActual = this.raiz;
        colaDeNodos.add(nodoActual);
        while(!colaDeNodos.isEmpty()) {
            nodoActual = colaDeNodos.poll();
            if (nodoActual.esVacioHijoIzquierdo()){
                cantidadDeHijosVacios = cantidadDeHijosVacios + 1;
            }
            if (nodoActual.esVacioHijoDerecho()){
                cantidadDeHijosVacios = cantidadDeHijosVacios + 1;
            }
            if (!nodoActual.esVacioHijoIzquierdo()){
                colaDeNodos.add(nodoActual.getHijoIzquierdo());
            }
            if (!nodoActual.esVacioHijoDerecho()) {
                colaDeNodos.add(nodoActual.getHijoDerecho());
            }
        }
        return cantidadDeHijosVacios;
    }
    public List<K> recorridoPostOrden()  {
        List<K> recorrido = new LinkedList<K>();
        if (esArbolVacio()){
            return recorrido;
        }
        recorridoPostOrden(raiz,recorrido);
        return recorrido;
    }
    private void recorridoPostOrden(NodoBinario<K,V> nodoActual, List<K> recorrido){
        if (NodoBinario.esNodoVacio(nodoActual)) {
            return;
        }
        recorridoPostOrden(nodoActual.getHijoIzquierdo(),recorrido);
        recorridoPostOrden(nodoActual.getHijoDerecho(),recorrido);
        recorrido.add(nodoActual.getClave());
    }
    public int cantidadDeNodosIncompletosDesdeNivel(int desdeNivel) {
        if (esArbolVacio()) {
            return 0;
        }
        return cantidadDeNodosIncompletosDesdeNivel(this.raiz,desdeNivel, 0);
    }

    private int cantidadDeNodosIncompletosDesdeNivel(NodoBinario<K,V> nodoActual, int desdeNivel, int nivelActual) {
        if (NodoBinario.esNodoVacio(nodoActual)) {
            return 0;
        }
        int cantidadDeNodosIncompletosPorIzquierda = cantidadDeNodosIncompletosDesdeNivel(nodoActual.getHijoIzquierdo(), desdeNivel, nivelActual + 1);
        int cantidadDeNodosIncompletosPorDerecha   = cantidadDeNodosIncompletosDesdeNivel(nodoActual.getHijoDerecho(), desdeNivel, nivelActual + 1);
        if (nivelActual >= desdeNivel) {
            if (nodoActual.esHoja()){
                return cantidadDeNodosIncompletosPorDerecha+ cantidadDeNodosIncompletosPorIzquierda + 2;
            }
            if (nodoActual.esVacioHijoDerecho()) {
                return cantidadDeNodosIncompletosPorIzquierda + cantidadDeNodosIncompletosPorDerecha + 1;
            }
            if (nodoActual.esVacioHijoIzquierdo()) {
                return cantidadDeNodosIncompletosPorIzquierda + cantidadDeNodosIncompletosPorDerecha + 1;
            }
        }
        return cantidadDeNodosIncompletosPorIzquierda + cantidadDeNodosIncompletosPorDerecha;
    }
}
