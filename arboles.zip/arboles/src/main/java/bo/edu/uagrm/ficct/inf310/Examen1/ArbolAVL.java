package bo.edu.uagrm.ficct.inf310.Examen1;

import bo.edu.uagrm.ficct.inf310.arboles.*;

import java.util.*;

public class ArbolAVL<K extends Comparable<K>,V> extends AVL<K,V> {
    public void insertar1(K clave, V valor) throws ExceptionClaveYaExiste{
        if (this.esArbolVacio()) {
            this.raiz = new NodoBinario<>(clave, valor);
            return;
        }
        List<NodoBinario<K, V>> listaDeNodos = new LinkedList<>();
        NodoBinario<K, V> nodoActual = this.raiz;


        NodoBinario<K, V> nodoAnterior = nodoActual;
        while(!NodoBinario.esNodoVacio(nodoActual)) {
            K claveActual = nodoActual.getClave();
            nodoAnterior = nodoActual;
            if (clave.compareTo(claveActual) < 0) {
                listaDeNodos.add(nodoActual);
                nodoActual = nodoActual.getHijoIzquierdo();
            }else{
                if (clave.compareTo(claveActual) > 0){
                    listaDeNodos.add(nodoActual);
                    nodoActual = nodoActual.getHijoDerecho();
                }else{
                    throw new ExceptionClaveYaExiste();
                }
            }

        }NodoBinario<K, V> nuevoNodo = new NodoBinario<>(clave, valor);
        if (clave.compareTo(nodoAnterior.getClave()) < 0) {
            nodoAnterior.setHijoIzquierdo(nuevoNodo);

        }else{
            nodoAnterior.setHijoDerecho(nuevoNodo);
        }

        int cantidadDeNodosEnLista = listaDeNodos.size();
        int posicionSuperior = cantidadDeNodosEnLista - 1;
        int posicionInferior = posicionSuperior - 1;


        while(cantidadDeNodosEnLista > 1) {
            NodoBinario<K, V> nodoSuperior = listaDeNodos.get(posicionSuperior);
            NodoBinario<K, V> nodoInferior = listaDeNodos.get(posicionInferior);

            if (nodoSuperior.getClave().compareTo(nodoInferior.getClave()) > 0) {
                nodoInferior.setHijoDerecho(balancear(nodoSuperior));
            } else {
                nodoInferior.setHijoIzquierdo(balancear(nodoSuperior));
            }

            cantidadDeNodosEnLista = cantidadDeNodosEnLista - 1;
            posicionSuperior = posicionSuperior - 1;
            posicionInferior = posicionInferior - 1;
        }
        this.raiz= balancear(listaDeNodos.get(0));


        /*int cantidadDeNodosEnPila = pilaDeNodos.size();
        NodoBinario<K , V> nodoEnPila;
        while(cantidadDeNodosEnPila > 0) {
            nodoEnPila = pilaDeNodos.pop();
            balancear(nodoEnPila);

            cantidadDeNodosEnPila = cantidadDeNodosEnPila - 1;
        }*/
    }
}
