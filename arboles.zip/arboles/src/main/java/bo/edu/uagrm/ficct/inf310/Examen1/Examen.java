package bo.edu.uagrm.ficct.inf310.Examen1;

public class Examen {
    public static void main (String[] args) {
        //Primera pregunta ----------------------------------------------
        ArbolABB ABB = new ArbolABB();
        try {
            ABB.insertar(5, "nombre1");
            ABB.insertar(2, "nombre2");
            ABB.insertar(65, "nombre3");
            ABB.insertar(19, "nombre4");
            ABB.insertar(82, "nombre5");
            ABB.insertar(18, "nombre6");
            ABB.insertar(32, "nombre7");
            ABB.insertar(72, "nombre8");
            ABB.insertar(73, "nombre8");
        } catch (Exception ex) {
            System.out.println("Error");
        }
        System.out.println(ABB);
        System.out.println("(1) Verificar si el árbol es monticulo: " + ABB.esMonticulo());

        //Segunda pregunta ----------------------------------------------
        ArbolAVL AVL = new ArbolAVL();
        try {
            AVL.insertar1(5, "nombre1");
            AVL.insertar1(2, "nombre2");
            AVL.insertar1(65, "nombre3");
            AVL.insertar1(19, "nombre4");
            AVL.insertar1(82, "nombre5");
            AVL.insertar1(18, "nombre6");
            AVL.insertar1(32, "nombre7");
            AVL.insertar1(72, "nombre8");
            AVL.insertar1(73, "nombre9");
        } catch (Exception ex) {
            System.out.println("Error");
        }
        System.out.println("(2) Árbol balanceado: ");
        System.out.println(AVL.toString());

        //Tercera pregunta ----------------------------------------------

        try {
            ArbolAMV AMV = new ArbolAMV(4);

            AMV.insertar(500,"nombre1");
            AMV.insertar(700,"nombre1");
            AMV.insertar(800,"nombre1");
            AMV.insertar(200,"nombre1");
            AMV.insertar(300,"nombre1");
            AMV.insertar(350,"nombre1");
            AMV.insertar(550,"nombre1");
            AMV.insertar(600,"nombre1");
            AMV.insertar(650,"nombre1");
            AMV.insertar(850,"nombre1");
            AMV.insertar(900,"nombre1");
            AMV.insertar(950,"nombre1");
            AMV.insertar(100,"nombre1");
            AMV.insertar(150,"nombre1");
            AMV.insertar(510,"nombre1");
            AMV.insertar(530,"nombre1");
            AMV.insertar(540,"nombre1");
            AMV.insertar(610,"nombre1");
            AMV.insertar(630,"nombre1");
            AMV.insertar(640,"nombre1");
            AMV.insertar(860,"nombre1");
            AMV.insertar(870,"nombre1");
            AMV.insertar(890,"nombre1");
            AMV.insertar(520,"nombre1");
            AMV.insertar(615,"nombre1");
            AMV.insertar(892,"nombre1");

            System.out.println("(3) ArbolMVias -> Cantidad de nodos padres fuera del nivel: " + AMV.cantidadDeNodosPadresFueraDelNivel(3));
        }catch(Exception ex){
            System.out.println("Error");
        }

    }
}
