package bo.edu.uagrm.ficct.inf310.arboles;

import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

public class ArbolMviasBusqueda<K extends Comparable<K>,V> implements IArbolBusqueda<K, V>  {
    protected NodoMVias<K, V> raiz;
    protected int orden;

    public ArbolMviasBusqueda() {
        this.orden = 3;
    }

    public ArbolMviasBusqueda(int orden) throws ExcepcionOrdenInvalido{
        if (orden < 3) {
            throw new  ExcepcionOrdenInvalido();
        }
        this.orden = orden;
    }
    public  NodoMVias<K,V> nodoVacioParaElArbol() {
       return (NodoMVias<K,V>)NodoMVias.nodoVacio();
    }

    /**
     * Metodo insertar iterativo
     * @param clave
     * @param valor
     * @throws ExceptionClaveYaExiste
     */
    public void insertar(K clave, V valor) throws ExceptionClaveYaExiste {
        if (this.esArbolVacio()) {
            this.raiz = new NodoMVias<K, V>(orden, clave, valor);
            return;
        }
        NodoMVias<K ,V> nodoActual = this.raiz;
        while (!NodoMVias.esNodoVacio(nodoActual)) {
            if(this.existeClaveEnNodo(nodoActual, clave)){
                throw new ExceptionClaveYaExiste();
            }
            //si llegamos a este punto la clave no esta en el nodoActual
            if (nodoActual.esHoja()) {
                if (nodoActual.estanDatosLlenos()) {
                    int posicionPorDondeBajar = this.porDondeBajar(nodoActual, clave);
                    NodoMVias<K, V> nuevoHijo= new NodoMVias<K, V>(orden, clave, valor);
                    nodoActual.setHijo(posicionPorDondeBajar, nuevoHijo);
                } else {
                    this.insertarEnOrden(nodoActual, clave, valor);
                }
                nodoActual = NodoMVias.nodoVacio();
            } else {
                int posicionPorDondeBajar = this.porDondeBajar(nodoActual, clave);
                if (nodoActual.esHijoVacio(posicionPorDondeBajar)) {
                    NodoMVias<K, V> nuevoHijo = new NodoMVias<K, V>(orden ,clave, valor);
                    nodoActual.setHijo(posicionPorDondeBajar, nuevoHijo);
                    nodoActual = NodoMVias.nodoVacio();
                } else {
                    nodoActual = nodoActual.getHijo(posicionPorDondeBajar);
                }
            }
        }
    }

    private boolean existeClaveEnNodo(NodoMVias<K,V> nodoActual, K claveABuscar) {
        for (int i = 0; i < orden - 1; i++) {
            if (!nodoActual.esDatoVacio(i)) {
                K claveEnTurno = nodoActual.getClave(i);
                if (claveABuscar.compareTo(claveEnTurno) == 0) {
                    return true;
                }
            }
        }
        return false;
    }

    private void insertarEnOrden(NodoMVias<K,V> nodoActual, K claveAInsertar, V valorAInsertar) {
        for (int i = 0;i < orden - 1; i++) {
            K claveEnTurno = nodoActual.getClave(i);
            if (claveEnTurno == null) {
                nodoActual.setClave(i, claveAInsertar);
                nodoActual.setValor(i, valorAInsertar);
                return;
            }
            if (claveAInsertar.compareTo(claveEnTurno) < 0) {
                int indiceDeDatoSuperior = orden - 2;
                int indiceDeDatoInferior = indiceDeDatoSuperior - 1;
                while (indiceDeDatoSuperior > i) {
                    K claveDeTurno = nodoActual.getClave(indiceDeDatoInferior);
                    V valorDeTurno = nodoActual.getValor(indiceDeDatoInferior);
                    nodoActual.setClave(indiceDeDatoSuperior, claveDeTurno);
                    nodoActual.setValor(indiceDeDatoSuperior, valorDeTurno);
                    indiceDeDatoSuperior = indiceDeDatoSuperior - 1;
                    indiceDeDatoInferior = indiceDeDatoInferior - 1;
                }
                nodoActual.setClave(i, claveAInsertar);
                nodoActual.setValor(i, valorAInsertar);
                return;
            }

        }
    }

    private int porDondeBajar(NodoMVias<K,V> nodoActual, K claveABuscar) {
        for (int i = 0;i < orden - 1; i++) {
            K claveDeTurno = nodoActual.getClave(i);
            if (claveABuscar.compareTo(claveDeTurno) < 0) {
                return i;
            }
        }
        return orden - 1;
    }

    public V eliminar(K clave) throws ExceptionClaveNoExiste {
        V valorARetornar = buscar(clave);
        if (valorARetornar == null) {
            throw new ExceptionClaveNoExiste();
        }
        this.raiz = eliminar(this.raiz, clave);
        return valorARetornar;
    }
    private NodoMVias<K, V> eliminar(NodoMVias<K, V> nodoActual, K claveAEliminar) {
        for(int i = 0;i < nodoActual.cantidadDeDatosNoVacios(); i++) {
            K claveActual = nodoActual.getClave(i);
            if (claveAEliminar.compareTo(claveActual) ==0) {
                if (nodoActual.esHoja()) {
                    this.eliminarDatoDeNodo(nodoActual, i);
                    if (nodoActual.estanDatosVacios()) {
                        return NodoMVias.nodoVacio();
                    }
                    return nodoActual;
                }
                K claveDeReemplazo;
                if (this.hayHijosMasAdelante(nodoActual, i)){
                    claveDeReemplazo = this.buscarSucesorInOrden(nodoActual, claveAEliminar);
                } else {
                    claveDeReemplazo = this.buscarPredecesorInOrden(nodoActual, claveAEliminar);
                }
                V valorDeReemplazo = this.buscar(claveDeReemplazo);
                nodoActual = eliminar(nodoActual, claveDeReemplazo);
                nodoActual.setClave(i, claveDeReemplazo);
                nodoActual.setValor(i, valorDeReemplazo);
                return nodoActual;
            }
            if (claveAEliminar.compareTo(claveActual) < 0) {
                NodoMVias<K, V> supuestoNuevoHijo = this.eliminar(nodoActual.getHijo(i), claveAEliminar);
                nodoActual.setHijo(i, supuestoNuevoHijo);
                return nodoActual;
            }
        }
        NodoMVias<K, V> supuestoNuevoHijo = this.eliminar(nodoActual.getHijo(orden - 1), claveAEliminar);
        nodoActual.setHijo(orden - 1, supuestoNuevoHijo);
        return nodoActual;
    }
    private K buscarPredecesorInOrden(NodoMVias<K,V> nodoActual, K claveAEliminar) {
        return claveAEliminar;
    }

    private K buscarSucesorInOrden(NodoMVias<K,V> nodoActual, K claveAEliminar) {
        return claveAEliminar;
    }

    private boolean hayHijosMasAdelante(NodoMVias<K,V> nodoActual, int i) {
        return true;
    }

    private void eliminarDatoDeNodo(NodoMVias<K,V> nodoActual, int i) {
        if (i == 0) {
             nodoActual.setValor(i, (V)NodoMVias.datoVacio());
             return;
        }
        int indiceInferior = i;
        int indiceSuperior = indiceInferior + 1;
        while (indiceInferior < nodoActual.cantidadDeDatosNoVacios()) {

            nodoActual.setClave(indiceInferior,nodoActual.getClave(indiceSuperior));
            nodoActual.setValor(indiceInferior, nodoActual.getValor(indiceSuperior));
            indiceInferior = indiceInferior + 1;
            indiceSuperior = indiceSuperior + 1;

        }
    }

    public V buscar(K claveABuscar) {
        NodoMVias<K,V> nodoActual = this.raiz;
        while(!NodoMVias.esNodoVacio(nodoActual)) {
            NodoMVias<K,V> nodoAnterior = nodoActual;
            //Inicio del for
            for (int i = 0; i < nodoActual.cantidadDeDatosNoVacios() &&
                    nodoAnterior == nodoActual; i++) {
                    K claveActual = nodoActual.getClave(i);
                if (claveABuscar.compareTo(claveActual) == 0) {
                    return nodoActual.getValor(i);
                }
                if (claveABuscar.compareTo(claveActual) < 0) {
                    if (nodoActual.esHijoVacio(i)) {
                        return (V)NodoMVias.datoVacio();
                    }
                    nodoActual = nodoActual.getHijo(i);
                }
            }//Fin del for
            if (nodoActual == nodoAnterior) {
                nodoActual = nodoAnterior.getHijo(orden - 1);
            }
        }
        return (V)NodoMVias.datoVacio();
    }

    public boolean contiene(K clave) {
        return this.buscar(clave) != NodoMVias.datoVacio();
    }

    public int size() {
        return this.size(this.raiz);
    }
    private int size(NodoMVias<K,V> nodoActual){
        if (NodoMVias.esNodoVacio(nodoActual)) {
            return 0;
        }
        int cantidad = 0;

        for (int i = 0; i < orden; i++) {
            cantidad = cantidad + size(nodoActual.getHijo(i));
        }
        cantidad = cantidad + 1;
        return cantidad;
    }
    public int altura() {
        return altura(this.raiz);
    }
    private int altura(NodoMVias<K, V> nodoActual) {
        if (NodoMVias.esNodoVacio(nodoActual)) {
            return 0;
        }
        int alturaMayor = 0;
        for (int i = 0; i < orden; i++) {
            int alturaDeHijo = altura(nodoActual.getHijo(i));
            if (alturaDeHijo > alturaMayor) {
                alturaMayor = alturaDeHijo;
            }
        }
        return alturaMayor + 1;
    }
    public void vaciar() {
        this.raiz = this.nodoVacioParaElArbol();
    }

    public boolean esArbolVacio() {
        return NodoMVias.esNodoVacio(this.raiz);
    }

    public int nivel() {
        return altura() - 1;
    }

    public List<K> recorridoEnInorden() {
        List<K> recorrido = new LinkedList<K>();
        this.recorridoEnInOrdenRecursivo(this.raiz, recorrido);
        return recorrido;
    }
    public void recorridoEnInOrdenRecursivo(NodoMVias<K, V> nodoActual, List<K> recorrido) {
        if (NodoMVias.esNodoVacio(nodoActual)) {
            return;
        }
        for (int i = 0; i < nodoActual.cantidadDeDatosNoVacios(); i++) {
            recorridoEnInOrdenRecursivo(nodoActual.getHijo(i), recorrido);
            recorrido.add(nodoActual.getClave(i));
        }
        recorridoEnInOrdenRecursivo(nodoActual.getHijo(orden - 1), recorrido);
    }

    public List<K> recorridoEnPreorden() {
        List<K> recorrido = new LinkedList<K>();
        this.recorridoEnPreordenRecursivo(this.raiz, recorrido);
        return recorrido;
    }
    private void recorridoEnPreordenRecursivo(NodoMVias<K,V> nodoActual, List<K> recorrido) {
        if (NodoMVias.esNodoVacio(nodoActual)){
            return;
        }
        for (int i = 0; i < nodoActual.cantidadDeDatosNoVacios(); i++) {
            recorrido.add(nodoActual.getClave(i));
            recorridoEnPreordenRecursivo(nodoActual.getHijo(i), recorrido);
        }
        recorridoEnPreordenRecursivo(nodoActual.getHijo(orden - 1), recorrido);
    }
    public List<K> recorridoEnPostorden() {
        List<K> recorrido = new LinkedList<K>();
        this.recorridoEnPostOrdenRecursivo(this.raiz, recorrido);
        return recorrido;
    }
    public void recorridoEnPostOrdenRecursivo(NodoMVias<K, V> nodoActual, List<K> recorrido) {
        if (NodoMVias.esNodoVacio(nodoActual)) {
            return;
        }
        recorridoEnPostOrdenRecursivo(nodoActual.getHijo(0), recorrido);
        for (int i = 0; i < nodoActual.cantidadDeDatosNoVacios(); i++) {
            recorridoEnPostOrdenRecursivo(nodoActual.getHijo(i+1), recorrido);
            recorrido.add(nodoActual.getClave(i));
        }
    }
    public List<K> recorridoPorNiveles() {
        List<K> recorrido = new LinkedList<K>();
        if (this.esArbolVacio()) {
            return recorrido;
        }
        Queue<NodoMVias<K,V>> colaDeNodos = new LinkedList<NodoMVias<K,V>>();
        colaDeNodos.offer(this.raiz);
        while (!colaDeNodos.isEmpty()) {
            NodoMVias<K,V> nodoActual = colaDeNodos.poll();
            for (int i = 0; i < nodoActual.cantidadDeDatosNoVacios(); i++) {
                recorrido.add(nodoActual.getClave(i));
                if (!nodoActual.esHijoVacio(i)) {
                    colaDeNodos.offer(nodoActual.getHijo(i));
                }
            }

            if (!nodoActual.esHijoVacio(orden - 1)){
                colaDeNodos.offer(nodoActual.getHijo(orden - 1));
            }
        }
        return recorrido;
    }
    public int hojasAPartirDeNivel(int nivelObjetivo) {
        return hojasAPartirDeNivel(this.raiz, nivelObjetivo, 0);
    }
    private int hojasAPartirDeNivel(NodoMVias<K,V> nodoActual, int nivelObjetivo, int nivelActual) {
        if (NodoMVias.esNodoVacio(nodoActual)) {
            return 0;
        }

        if (nivelActual >= nivelObjetivo) {
            if (nodoActual.esHoja()) {
                return 1;
            }
        }
        int cantidadDeHojas = 0;
        for (int i = 0; i < orden; i++) {
            cantidadDeHojas = cantidadDeHojas + this.hojasAPartirDeNivel(nodoActual.getHijo(i), nivelObjetivo, nivelActual + 1);
        }
        return cantidadDeHojas;
    }
    private NodoMVias<K, V> eliminar1(NodoMVias<K, V> nodoActual, K claveAEliminar) {

        for (int i = 0; i < nodoActual.cantidadDeDatosNoVacios(); i++) {
            K claveActual = nodoActual.getClave(i);
            if (claveAEliminar.compareTo(claveActual) == 0) {
                if (nodoActual.esHoja()) {
                    this.eliminarDatoDeNodo(nodoActual, i);
                    if (nodoActual.estanDatosVacios()) {
                        return NodoMVias.nodoVacio();
                    }
                    return nodoActual;
                }
                K claveDeRemplazo;
                if (this.hayHijosMasAdelante(nodoActual, i)) {
                    claveDeRemplazo = this.buscarSucesorInOrden(nodoActual, claveAEliminar);
                }else{
                    claveDeRemplazo = this.buscarPredecesorInOrden(nodoActual, claveAEliminar);
                }
                V valorDeRemplazo = this.buscar(claveDeRemplazo);
                nodoActual = eliminar1(nodoActual, claveDeRemplazo);
                nodoActual.setClave(i, claveDeRemplazo);
                nodoActual.setValor(i, valorDeRemplazo);
                return nodoActual;
            }
            if (claveAEliminar.compareTo(claveActual) < 0) {
                NodoMVias<K, V> supuestoNuevoHijo = eliminar(nodoActual.getHijo(i), claveAEliminar);
                nodoActual.setHijo(i, supuestoNuevoHijo);
                return nodoActual;
            }
        }
        NodoMVias<K, V> supuestoNuevoHijo = eliminar1(nodoActual.getHijo(orden - 1), claveAEliminar);
        nodoActual.setHijo(orden - 1,supuestoNuevoHijo);
        return nodoActual;
    }
    public int cantidadDeNodosConDatosVacios(int nivel) {
        return cantidadDeNodosConDatosVacios(this.raiz, nivel, 0);
    }
    private int cantidadDeNodosConDatosVacios(NodoMVias<K, V> nodoActual, int nivel, int nivelActual) {
        if (NodoMVias.esNodoVacio(nodoActual)) {
            return 0;
        }
        if (nivel == nivelActual) {
            if (!nodoActual.estanDatosLlenos()) {
                return 1;
            }
        }
        int cantidadDatosVacios = 0;
        for (int i = 0; i < orden; i++) {
            cantidadDatosVacios = cantidadDatosVacios + cantidadDeNodosConDatosVacios(nodoActual.getHijo(i), nivel, nivelActual + 1);
        }

        return cantidadDatosVacios;
    }

}
